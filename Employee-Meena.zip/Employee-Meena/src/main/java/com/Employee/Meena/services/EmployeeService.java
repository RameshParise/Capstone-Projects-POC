package com.Employee.Meena.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.Employee.Meena.entities.Address;
import com.Employee.Meena.entities.Details;
import com.Employee.Meena.entities.Employee;
import com.Employee.Meena.repositories.AddressRepository;
import com.Employee.Meena.repositories.DetailsRepository;
import com.Employee.Meena.repositories.EmployeeReposirort;

@Service
public class EmployeeService {
		@Autowired
		private EmployeeReposirort empRepo;
		
		
		public Employee addAEmployee(Employee e) {
			return empRepo.save(e);
			}
		
		public List<Employee> getAllEmp(){
			return empRepo.findAll();
			
		}
		
		public Employee findById(int id) {
			return empRepo.getById(id);
		}
		
		
}


