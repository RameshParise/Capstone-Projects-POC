package com.Employee.Meena.entities;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Details {
	public Details() {
		super();
	}
	public Details(String higerEducation, String skill, String exp, String email) {
		super();
		this.HigerEducation = higerEducation;
		this.skill = skill;
		this.exp = exp;
		this.email = email;
	}
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	int detailsId;
	String HigerEducation;
	String skill;
	String exp;
	String email;
	public int getDetailsId() {
		return detailsId;
	}
	public void setDetailsId(int detailsId) {
		this.detailsId = detailsId;
	}
	public String getHigerEducation() {
		return HigerEducation;
	}
	public void setHigerEducation(String higerEducation) {
		HigerEducation = higerEducation;
	}
	public String getSkill() {
		return skill;
	}
	public void setSkill(String skill) {
		this.skill = skill;
	}
	public String getExp() {
		return exp;
	}
	public void setExp(String exp) {
		this.exp = exp;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}

}
