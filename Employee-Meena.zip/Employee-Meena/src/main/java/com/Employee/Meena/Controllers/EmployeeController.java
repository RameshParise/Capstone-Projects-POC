package com.Employee.Meena.Controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.Employee.Meena.entities.Address;
import com.Employee.Meena.entities.Details;
import com.Employee.Meena.entities.Employee;
import com.Employee.Meena.services.EmployeeService;

@RestController
@RequestMapping("/app")
public class EmployeeController {
	@Autowired
	private EmployeeService empService;
	
	@PostMapping("/add")
	public ResponseEntity<Employee> addaEmp(@RequestBody Employee e) {
		return new ResponseEntity(empService.addAEmployee(e),HttpStatus.CREATED);
	}
	
	
	@GetMapping("/getAll")
	public ResponseEntity<List<Employee>> GetAllEmp() {
		return new ResponseEntity(empService.getAllEmp(),HttpStatus.OK);
	}
	
	@GetMapping("/getById/{id}")
	public Employee getById(@PathVariable int id) {
		return empService.findById(id);
	}
	
	@GetMapping("/getaddressByEmpId/{id}")
	public Address getAddressByEmpId(@PathVariable int id) {
		return getById(id).getAddress();

	}
	
	@GetMapping("/getDetailsByEmpId/{id}")
	public Details getDetailsByEmpId(@PathVariable int id) {
		return getById(id).getDetails();
	}

}
