package com.Employee.Meena.entities;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToOne;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Address {
	public Address() {
		super();
	}
	public Address( String address, String city, String zipCode) {
		super();
		
		this.address = address;
		this.city = city;
		this.zipCode = zipCode;
	}
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	int AddressId;
	String address;
	String city;
	String zipCode;
//	@OneToOne(cascade = CascadeType.ALL,mappedBy = "Employee")
//	private Employee employee;
	public int getAddressId() {
		return AddressId;
	}
	public void setAddressId(int addressId) {
		AddressId = addressId;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getZipCode() {
		return zipCode;
	}
	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}

	
}
