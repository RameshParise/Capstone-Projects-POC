package com.Employee.Meena.entities;


import java.beans.JavaBean;

import org.hibernate.annotations.GenericGenerator;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Data
@JavaBean
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Employee {

	

	public Employee(String firstName, String middletName, String lastName, long mobNum, Address address,
			Details details) {
		super();
//		this.empId=id;
		this.firstName = firstName;
		this.middletName = middletName;
		this.lastName = lastName;
		this.mobNum = mobNum;
		this.address = address;
		this.details = details;
	}

	public Employee() {
		super();
	}

	

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	int empId;
	String firstName;
	String middletName;
	String lastName;
	long mobNum;
	
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name="Address_id", referencedColumnName = "AddressId")
	private Address address;
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name="Details_id", referencedColumnName = "detailsId")
	private Details details;
	public int getEmpId() {
		return empId;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getMiddletName() {
		return middletName;
	}

	public void setMiddletName(String middletName) {
		this.middletName = middletName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public long getMobNum() {
		return mobNum;
	}

	public void setMobNum(long mobNum) {
		this.mobNum = mobNum;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	public Details getDetails() {
		return details;
	}

	public void setDetails(Details details) {
		this.details = details;
	}


	
}
