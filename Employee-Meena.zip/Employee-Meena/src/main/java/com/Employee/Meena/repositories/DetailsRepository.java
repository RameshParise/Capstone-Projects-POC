package com.Employee.Meena.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.Employee.Meena.entities.Details;

@Repository
public interface DetailsRepository extends JpaRepository<Details, Integer> {

}
